# Experimental Forensic Analysis Report

Case ID: phase9d_ai_fabricated_002_ai_005_fabricated
Status: experimental_forensic_prototype

## Summary
Experimental prototype evidence indicators generated from packaged Phase 9B models. Fusion status: suspicious_origin_experimental. Successful axis predictions: 4/4. Candidate segments: 5. Manual review required. Output is consistent with multi-axis review workflow support only.

## Evidence axes (separate indicators)
Origin: experimental evidence indicator 'elevated_ai_origin_indicator' (strength=high, probability=0.999). This is not a final forensic proof.
Replay: experimental evidence indicator 'low_indicator' (strength=low, probability=0.000). This is not a final forensic proof.
Mixer/channel: experimental evidence indicator 'low_indicator' (strength=low, probability=0.000). This is not a final forensic proof.
Partial fabrication: partial segment activation was broad across the file, so it is not treated as localized partial-fabrication evidence.

## Candidate segments
Top candidate segments: candidate segment seg_0001 (2.0s-6.0s) partial indicator=1.0; candidate segment seg_0002 (4.0s-8.0s) partial indicator=1.0; candidate segment seg_0004 (8.0s-12.0s) partial indicator=1.0. Manual review recommended.

## Fusion
Fusion status: suspicious_origin_experimental
Risk level: medium
Manual review required: True

## Limitations
- experimental_forensic_prototype
- multi-axis evidence only; no single binary authenticity score
- AASIST/HybridResNet reference models inactive
- manual review recommended for elevated or mixed indicators
