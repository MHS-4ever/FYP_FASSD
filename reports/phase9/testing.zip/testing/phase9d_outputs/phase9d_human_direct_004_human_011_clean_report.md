# Experimental Forensic Analysis Report

Case ID: phase9d_human_direct_004_human_011_clean
Status: experimental_forensic_prototype

## Summary
Experimental prototype evidence indicators generated from packaged Phase 9B models. Fusion status: inconclusive_manual_review_experimental. Successful axis predictions: 4/4. Candidate segments: 5. Manual review required. Output is consistent with multi-axis review workflow support only.

## Evidence axes (separate indicators)
Origin: experimental evidence indicator 'low_indicator' (strength=low, probability=0.009). This is not a final forensic proof.
Replay: experimental evidence indicator 'low_indicator' (strength=low, probability=0.007). This is not a final forensic proof.
Mixer/channel: experimental evidence indicator 'low_indicator' (strength=low, probability=0.045). This is not a final forensic proof.
Partial fabrication: partial segment activation was broad across the file, so it is not treated as localized partial-fabrication evidence.

## Candidate segments
Top candidate segments: candidate segment seg_0008 (16.0s-20.0s) partial indicator=1.0; candidate segment seg_0019 (38.0s-41.728s) partial indicator=1.0; candidate segment seg_0005 (10.0s-14.0s) partial indicator=1.0. Manual review recommended.

## Fusion
Fusion status: inconclusive_manual_review_experimental
Risk level: inconclusive
Manual review required: True

## Limitations
- experimental_forensic_prototype
- multi-axis evidence only; no single binary authenticity score
- AASIST/HybridResNet reference models inactive
- manual review recommended for elevated or mixed indicators
